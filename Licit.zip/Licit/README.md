# SA-LicitaNet
Situação de Aprendizagem - Atualização Tecnológica em Informática
